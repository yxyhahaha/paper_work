import os
from ete3 import Tree

# Function to calculate RF distance
def calculate_rf_distance(tree1_path, tree2_path):
    try:
        # Load the trees
        tree1 = Tree(tree1_path, format=1)
        tree2 = Tree(tree2_path, format=1)
        
        # Calculate RF distance
        rf_distance, max_rf, *_ = tree1.robinson_foulds(tree2)
        normalized_rf = rf_distance / max_rf if max_rf > 0 else 0
        return rf_distance, normalized_rf
    except Exception as e:
        return f"Error calculating RF distance for {tree1_path}: {e}", None

# Function to process tree files in a folder
def process_trees(input_folder, gold_standard_path):
    for i in range(1, 11):  # Subfolders named 1 to 5
        subfolder_path = os.path.join(input_folder, str(i))
        if not os.path.isdir(subfolder_path):
            print(f"Subfolder {subfolder_path} does not exist.")
            continue

        # Define paths for Concatenation and Coalescent trees
        concatenation_tree = os.path.join(subfolder_path, "Concatenation.tree")
        coalescent_tree = os.path.join(subfolder_path, "Coalescent.tree")

        # Process Concatenation.tree
        if os.path.exists(concatenation_tree):
            rf_distance, normalized_rf = calculate_rf_distance(concatenation_tree, gold_standard_path)
            print(f"[{i}] Concatenation.tree -> RF Distance: {rf_distance}, Normalized RF Distance: {normalized_rf}")

        # Process Coalescent.tree
        if os.path.exists(coalescent_tree):
            rf_distance, normalized_rf = calculate_rf_distance(coalescent_tree, gold_standard_path)
            print(f"[{i}] Coalescent.tree -> RF Distance: {rf_distance}, Normalized RF Distance: {normalized_rf}")

# Define input folder and gold standard tree path
input_folder = "gm-after"  # Replace with your input folder path
gold_standard_path = "./3.tree"  # Replace with the gold standard tree path

# Process the trees
process_trees(input_folder, gold_standard_path)
