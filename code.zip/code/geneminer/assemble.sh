#!/bin/bash
set -eu

: ${kmer_size:=31}
: ${step_size:=4}
: ${limit_count:=2}
: ${soft_boundary:="-1"}

rm -rf ../output/$1
mkdir ../output/$1

readarray -t read_list < ../../$1_list.txt
readarray -t name_list < ../../name_list.txt
spacer=${read_list[0]: -1}

bin/MainFilterNew -r reference -o ../output/$1 -kf $kmer_size -s $step_size -gr -lkd ../output/$1/kmer_dict_${kmer_size}.dict -m 2
parallel --ungroup -j ${threads:-1} "bin/MainFilterNew -r reference -q1 ../../$1/{}${spacer}1.$2 -q2 ../../$1/{}${spacer}2.$2 -o ../output/$1/{} -kf $kmer_size -s $step_size -gr -lb -lkd ../output/$1/kmer_dict_${kmer_size}.dict -m 4 -subdir filtered_pe" ::: "${name_list[@]}"

for name in "${name_list[@]}"
do
    bin/main_refilter_new -qd ../output/$1/$name/filtered_pe -r reference -o ../output/$1/$name/filtered -kf $kmer_size --max-depth 768 --max-size 6 -p ${threads:-1}
done

for name in "${name_list[@]}"
do
    bin/main_assembler -r reference -o ../output/$1/$name -ka 0 -k_min 21 -k_max 51 -limit_count $limit_count -iteration 4096 -sb $soft_boundary -p ${threads:-1}
done
