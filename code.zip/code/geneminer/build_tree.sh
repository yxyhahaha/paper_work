#!/bin/bash
set -eu

: ${blast_mode:=2}
: ${blast_pec:=0}

readarray -t name_list < ../../name_list.txt

for name in "${name_list[@]}"
do
    mkdir -p ../output/$1/$name/blast
    ls reference | parallel --ungroup -j ${threads:-1} "test -e ../output/$1/$name/results/{} && tmp_dir=\$(mktemp -d) && bin/build_trimed -r reference/{} -i ../output/$1/$name/results/{} -o ../output/$1/$name/blast/{} -b \$tmp_dir -m $blast_mode --pec $blast_pec &> /dev/null && rm -rf \$tmp_dir" && true
done

rm -rf ../output/$1/combined && true
mkdir -p ../output/$1/combined/aligned
mkdir -p ../output/$1/combined/trimed
mkdir -p ../output/$1/combined/trees

for name in "${name_list[@]}"
do
    ls reference | parallel --ungroup -j ${threads:-1} "test -e ../output/$1/$name/blast/{} && echo '>'$name >> ../output/$1/combined/{} && tail -n +2 ../output/$1/$name/blast/{} >> ../output/$1/combined/{}" && true
done

ls reference | parallel --ungroup -j ${threads:-1} "test -e ../output/$1/combined/{} && mafft --auto ../output/$1/combined/{} > ../output/$1/combined/aligned/{} && trimal -automated1 -in ../output/$1/combined/aligned/{} -out ../output/$1/combined/trimed/{} && FastTree -gtr -nopr -nosupport -nt ../output/$1/combined/trimed/{} > ../output/$1/combined/trees/{.}.tree" && true

rm -f ../output/$1/combined_trees.tre && true

for gene in `ls reference`
do
    gene_name=${gene%.*}
    if [ -e ../output/$1/combined/trees/$gene_name.tree ]
    then
        cat ../output/$1/combined/trees/$gene_name.tree >> ../output/$1/combined_trees.tre
    fi
done

astral -i ../output/$1/combined_trees.tre -u 1 -o ../output/$1/coalescent.tre
