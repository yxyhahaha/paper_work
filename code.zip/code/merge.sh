for file in *.fasta; do
  awk '/^>/ {
    if ($0 ~ /A/) out="merge_qs20_nm/A.fasta";
    else if ($0 ~ /B/) out="merge_qs20_nm/B.fasta";
    else if ($0 ~ /C/) out="merge_qs20_nm/C.fasta";
    else if ($0 ~ /D/) out="merge_qs20_nm/D.fasta";
    else if ($0 ~ /E/) out="merge_qs20_nm/E.fasta";
    else if ($0 ~ /F/) out="merge_qs20_nm/F.fasta";
    else if ($0 ~ /G/) out="merge_qs20_nm/G.fasta";
    else if ($0 ~ /H/) out="merge_qs20_nm/H.fasta";
    else if ($0 ~ /I/) out="merge_qs20_nm/I.fasta";
    else if ($0 ~ /J/) out="merge_qs20_nm/J.fasta";
  } out {print >> out}' "$file";
done
