import os
from pathlib import Path

folders = [1, 2, 3, 4, 5,6,7,8,9,10]
subfolders = ['A', 'B', 'C', 'D', 'E', 'F', 'G','H','I','J']
output_folder = "combine"

for folder in folders:
    combine_path = f"./{folder}/mega/{output_folder}"
    if not os.path.exists(combine_path):
        os.makedirs(combine_path)

    file_names = set()
    for subfolder in subfolders:
        output_path = f"./{folder}/mega/{subfolder}/output"
        if os.path.exists(output_path):
            file_names.update(os.listdir(output_path))

    for file_name in file_names:
        combined_file_path = os.path.join(combine_path, file_name)
        with open(combined_file_path, "w") as combined_file:
            for subfolder in subfolders:
                source_file_path = f"./{folder}/mega/{subfolder}/output/{file_name}"
                if os.path.exists(source_file_path):
                    with open(source_file_path, "r") as source_file:
                        combined_file.write(source_file.read())
                        combined_file.write("\n")
        print(f"files {file_name} were combined to  {combined_file_path}")
