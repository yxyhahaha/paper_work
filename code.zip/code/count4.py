import pandas as pd
import argparse

parser = argparse.ArgumentParser(description="Classify sequence identity levels and save results.")
parser.add_argument("-i", "--input", required=True, help="Path to the input CSV file.")
parser.add_argument("-o", "--output", required=True, help="Path to the output CSV file.")
args = parser.parse_args()

csv_file = args.input
output_csv = args.output

data = pd.read_csv(csv_file)

level_counts = {'Level 1': 0, 'Level 2': 0, 'Level 3': 0, 'Level 4': 0, 'Level 5': 0}

for index, row in data.iterrows():
    min_identity = row['Min Identity']
    avg_coverage = row['Avg Coverage']
    total_sequences = row['Total Sequences']

    if min_identity == 100:
        if 7 <= total_sequences <= 10:
            if 0.5 <= avg_coverage <= 1:
                level_counts['Level 1'] += 1
            elif avg_coverage < 0.5:
                level_counts['Level 2'] += 1
        elif 1 <= total_sequences <= 6:
            if 0.5 <= avg_coverage < 1:
                level_counts['Level 3'] += 1
            elif avg_coverage < 0.5:
                level_counts['Level 4'] += 1
    elif 90 <= min_identity < 100:
        level_counts['Level 5'] += 1

output_df = pd.DataFrame(level_counts.items(), columns=['Level', 'Count'])
output_df.to_csv(output_csv, index=False)

print("=== Level Classification Summary ===")
print(output_df.to_string(index=False))
print(f"\nResults saved to: {output_csv}")
