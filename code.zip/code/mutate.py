import os
import random
from Bio import SeqIO
from Bio.Seq import Seq

def mutate_sequence(sequence, mutation_rate):
    bases = ['A', 'T', 'C', 'G']
    sequence = list(sequence)
    mutation_positions = random.sample(range(len(sequence)), int(len(sequence) * mutation_rate))
    for pos in mutation_positions:
        sequence[pos] = random.choice([b for b in bases if b != sequence[pos]])
    return ''.join(sequence)

input_folder = "."
output_folder = "mutated0.2"
os.makedirs(output_folder, exist_ok=True)

for file_name in os.listdir(input_folder):
    if file_name.endswith(".fasta"):
        input_file = os.path.join(input_folder, file_name)
        output_file = os.path.join(output_folder, f"{file_name}")
        
        mutated_records = []
        for record in SeqIO.parse(input_file, "fasta"):
            mutated_sequence = mutate_sequence(str(record.seq), mutation_rate=0.2)
            mutated_records.append(SeqIO.SeqRecord(Seq(mutated_sequence), id=record.id, description=record.description))
        
        SeqIO.write(mutated_records, output_file, "fasta")

print(f"Mutation completed. Results saved in folder: {output_folder}")
