import os
import random
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord

def generate_random_sequence(length):
    return "".join(random.choice(["A", "T", "C", "G"]) for _ in range(length))

def extend_sequence(record, extension_length=200):
    left_extension = generate_random_sequence(extension_length)
    right_extension = generate_random_sequence(extension_length)
    extended_sequence = left_extension + str(record.seq) + right_extension
    new_record = SeqRecord(Seq(extended_sequence), id=record.id, description=record.description)
    return new_record

def extend_fasta_files_in_folder(folder_path, extension_length=200):
    for filename in os.listdir(folder_path):
        if filename.endswith(".fasta"):
            input_fasta = os.path.join(folder_path, filename)
            output_fasta = os.path.join(folder_path, f"{os.path.splitext(filename)[0]}_extended.fasta")
            with open(output_fasta, "w") as output_handle:
                for record in SeqIO.parse(input_fasta, "fasta"):
                    extended_record = extend_sequence(record, extension_length)
                    SeqIO.write(extended_record, output_handle, "fasta")
            print(f"Processed {filename} -> {output_fasta}")

folder_path = "./"
extend_fasta_files_in_folder(folder_path, extension_length=200)
