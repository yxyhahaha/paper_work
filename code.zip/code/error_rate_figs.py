import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

ass_color = '#4DAB90'
gm_color = '#834127'

ass_scatter_color = '#4DAB90'
gm_scatter_color = '#834127'

summary_file = 'allseq_0.1rate.xlsx'
summary_ass = pd.read_excel(summary_file, sheet_name='0.1ass')
summary_gm = pd.read_excel(summary_file, sheet_name='0.1gm')

fig, ax1 = plt.subplots(figsize=(12, 6))

x_ticks = np.arange(1, 11)
x_positions = np.arange(0, 10) * 2

for i, depth in enumerate(range(1, 11)):
    ass_file = f'0.1ass/{depth}x.csv'
    gm_file = f'0.1gm/{depth}x.csv'
    
    if os.path.exists(ass_file):
        ass_data = pd.read_csv(ass_file)
        ass_error_rate = ass_data['Mismatch Error Rate'] * 100
        ass_error_rate_filtered = ass_error_rate[ass_error_rate < 1.5]
        violin_parts = ax1.violinplot(ass_error_rate_filtered, positions=[x_positions[i] - 0.4], widths=0.4, showmeans=False, showextrema=False, showmedians=False)
        for pc in violin_parts['bodies']:
            pc.set_facecolor(ass_color)
            pc.set_edgecolor('black')
            pc.set_alpha(0.6)
        ass_scatter_filtered = ass_error_rate[ass_error_rate < 1.5]
        ax1.scatter(np.full(len(ass_scatter_filtered), x_positions[i] - 0.4), ass_scatter_filtered, color=ass_scatter_color, alpha=0.5, s=10)
    
    if os.path.exists(gm_file):
        gm_data = pd.read_csv(gm_file)
        gm_error_rate = gm_data['Mismatch Error Rate'] * 100
        gm_error_rate_filtered = gm_error_rate[gm_error_rate < 1.5]
        violin_parts = ax1.violinplot(gm_error_rate_filtered, positions=[x_positions[i] + 0.4], widths=0.6, showmeans=False, showextrema=False, showmedians=False)
        for pc in violin_parts['bodies']:
            pc.set_facecolor(gm_color)
            pc.set_edgecolor('black')
            pc.set_alpha(0.6)
        gm_scatter_filtered = gm_error_rate[gm_error_rate < 1.5]
        ax1.scatter(np.full(len(gm_scatter_filtered), x_positions[i] + 0.4), gm_scatter_filtered, color=gm_scatter_color, alpha=0.5, s=10)

ax1.set_ylabel('Mismatch Error Rate (%)', color='black', fontsize=14)
ax1.tick_params(axis='y', labelcolor='black', labelsize=12)
ax1.tick_params(axis='x', which='major', labelsize=14)
ax1.set_ylim(0, 1.5)

ax2 = ax1.twinx()
ax2.plot(x_positions, summary_ass['Mismatch Error Rate'] * 100, color=ass_color, marker='o', label='Assemble')
ax2.plot(x_positions, summary_gm['Mismatch Error Rate'] * 100, color=gm_color, marker='o', label='Geneminer2')
ax2.tick_params(axis='y', labelcolor='black', labelsize=12)

ax1.set_xticks(x_positions)
ax1.set_xticklabels([f'{x}x' for x in x_ticks])
ax1.set_xlabel('Sequencing Depth', fontsize=14)

ax1.set_title("Mismatch Error Rate (ref_mutate=0.1)", fontsize=16)
ax1.legend([plt.Rectangle((0,0),1,1, fc=ass_color), plt.Rectangle((0,0),1,1, fc=gm_color)], ['Assemble', 'Geneminer2'], loc='center right')

plt.savefig('0.1_modified.png', dpi=300, bbox_inches='tight')
