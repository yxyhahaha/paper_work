import os
import subprocess
import argparse
from Bio import SeqIO
import pandas as pd

parser = argparse.ArgumentParser(description="Run BLAST for corresponding FASTA files in two folders and summarize results.")
parser.add_argument("-f1", "--folder1", required=True, help="Path to the gold standard FASTA files folder.")
parser.add_argument("-f2", "--folder2", required=True, help="Path to the comparison FASTA files folder.")
parser.add_argument("-o", "--output", required=True, help="Path to the output BLAST results folder.")
parser.add_argument("-csv", "--csv_output", required=True, help="Path to the final summary CSV file.")

args = parser.parse_args()

folder1 = args.folder1
folder2 = args.folder2
blast_output_folder = args.output
csv_output = args.csv_output

os.makedirs(blast_output_folder, exist_ok=True)

files1 = {os.path.basename(f): os.path.join(folder1, f) for f in os.listdir(folder1) if f.endswith('.fasta')}
files2 = {os.path.basename(f): os.path.join(folder2, f) for f in os.listdir(folder2) if f.endswith('.fasta')}

summary_data = []

for filename, path1 in files1.items():
    if filename in files2:
        path2 = files2[filename]
        output_path = os.path.join(blast_output_folder, f'blast_{filename.replace(".fasta", ".txt")}')
        subprocess.run(["blastn", "-query", path1, "-subject", path2,
                        "-outfmt", "6 qseqid sseqid pident length qlen", "-out", output_path], check=True)
        try:
            results = pd.read_csv(output_path, sep='\t', header=None, 
                                  names=['qseqid', 'sseqid', 'pident', 'length', 'qlen'])

            if not results.empty:
                results['coverage'] = results['length'] / results['qlen']
                filtered_results = results[results['qseqid'] == results['sseqid']]
                min_pident = filtered_results['pident'].min() if not filtered_results.empty else None
                avg_coverage = filtered_results['coverage'].sum() / len(filtered_results) if not filtered_results.empty else None
            else:
                min_pident = None
                avg_coverage = None

            total_count = sum(1 for _ in SeqIO.parse(path2, "fasta"))
            summary_data.append([filename, min_pident, avg_coverage, total_count])

        except FileNotFoundError:
            summary_data.append([filename, None, None, 0])

output_df = pd.DataFrame(summary_data, columns=['File Name', 'Min Identity', 'Avg Coverage', 'Total Sequences'])
output_df.to_csv(csv_output, index=False)

print(f"BLAST analysis completed for all matching files. Summary saved to {csv_output}")
