import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

file_path = "tree_plus.xlsx"
sheets = ["0.05", "0.1", "0.15", "0.2"]
data_dict = pd.read_excel(file_path, sheet_name=sheets)

heatmap_coal_data = []
heatmap_con_data = []
ref_labels = sheets

for sheet_name, df in data_dict.items():
    rf_diff_coal = df.iloc[:, 1].astype(str).replace("NULL", np.nan).astype(float)
    rf_diff_con = df.iloc[:, 2].astype(str).replace("NULL", np.nan).astype(float)

    heatmap_coal_data.append(rf_diff_coal.values)
    heatmap_con_data.append(rf_diff_con.values)

heatmap_coal_array = np.array(heatmap_coal_data, dtype=np.float32)
heatmap_con_array = np.array(heatmap_con_data, dtype=np.float32)

cmap_colors = ["#4DAB90", "#E1C69B", "#834127"]
custom_cmap = LinearSegmentedColormap.from_list("OrangeToBlue", cmap_colors, N=256)
custom_cmap.set_bad("#DA4E33")

fig, axes = plt.subplots(2, 1, figsize=(10, 10), sharex=True, gridspec_kw={'height_ratios': [1, 1], 'hspace': 0.05})
cbar_ax = fig.add_axes([0.92, 0.2, 0.02, 0.6])

ax1 = sns.heatmap(heatmap_coal_array, cmap=custom_cmap, vmin=-0.8, vmax=0.8, square=True,
                  xticklabels=range(1, 11), yticklabels=ref_labels, ax=axes[0], cbar=True, 
                  cbar_ax=cbar_ax, annot=True, fmt=".3f", linewidths=0.5, linecolor="black")
axes[0].set_title("RF Distance Difference (Coalescent)")
axes[0].set_xlabel("Sequencing Depth (x)")
axes[0].set_ylabel("Ref Variability")

ax2 = sns.heatmap(heatmap_con_array, cmap=custom_cmap, vmin=-0.8, vmax=0.8, square=True,
                  xticklabels=range(1, 11), yticklabels=ref_labels, ax=axes[1], cbar=False,
                  annot=True, fmt=".3f", linewidths=0.5, linecolor="black")
axes[1].set_title("RF Distance Difference (Concatenation)")
axes[1].set_xlabel("Sequencing Depth (x)")
axes[1].set_ylabel("Ref Variability")

fig.subplots_adjust(hspace=0.05)

output_heatmap_path = "heatmap.png"
plt.savefig(output_heatmap_path, dpi=300)
plt.close()

print(f"Optimized heatmap saved as {output_heatmap_path}")
