import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

file_path = "combine_qs20_ref0.05.xlsx"
xls = pd.ExcelFile(file_path)

gm_level = pd.read_excel(xls, sheet_name="gm_level")
ass_level = pd.read_excel(xls, sheet_name="ass_level")

gm_level.columns = ["Depth", "Level1", "Level2", "Level3", "Level4"]
ass_level.columns = ["Depth", "Level1", "Level2", "Level3", "Level4"]

gm_level["Depth"] = gm_level["Depth"].astype(str).str.strip()
ass_level["Depth"] = ass_level["Depth"].astype(str).str.strip()

depth_order = [f"{i}x" for i in range(1, 11)]
gm_level = gm_level.set_index("Depth").reindex(depth_order).reset_index()
ass_level = ass_level.set_index("Depth").reindex(depth_order).reset_index()

gm_level = gm_level.fillna(0)
ass_level = ass_level.fillna(0)

gm_level.loc[gm_level["Depth"] == "1x", ["Level1", "Level2", "Level3", "Level4"]] = [0, 879, 0, 121]
ass_level.loc[ass_level["Depth"] == "1x", ["Level1", "Level2", "Level3", "Level4"]] = [0, 0, 252, 611]

gm_FN = pd.read_excel(xls, sheet_name="gm_FN", skiprows=1)
ass_FN = pd.read_excel(xls, sheet_name="ass_FN", skiprows=1)

gm_FN.columns = ["Depth", "Concatenation_FN", "Coalescent_FN"]
ass_FN.columns = ["Depth", "Concatenation_FN", "Coalescent_FN"]

gm_FN["Depth"] = gm_FN["Depth"].astype(str).str.strip()
ass_FN["Depth"] = ass_FN["Depth"].astype(str).str.strip()

gm_FN = gm_FN.set_index("Depth").reindex(depth_order).reset_index().fillna(0)
ass_FN = ass_FN.set_index("Depth").reindex(depth_order).reset_index().fillna(0)

gm_FN.loc[gm_FN["Depth"] == "1x", ["Concatenation_FN", "Coalescent_FN"]] = [0, 0]
ass_FN.loc[ass_FN["Depth"] == "1x", ["Concatenation_FN", "Coalescent_FN"]] = [7, 6]

gm_colors  = ['#FB9B3B', '#89BF65', '#FFCA21', '#9CB4E0']
ass_colors = ['#FDAD5E', '#A9D18E', '#FFD966', '#C6D4ED']
gm_FN_colors = {"Concatenation": "black", "Coalescent": "gray"}
ass_FN_colors = {"Concatenation": "darkblue", "Coalescent": "dodgerblue"}

depths = gm_level["Depth"].astype(str).values  
x = np.arange(len(depths))
bar_width = 0.35

fig, ax = plt.subplots(figsize=(12, 6))

bottom = np.zeros(len(depths))
for i, level in enumerate(["Level1", "Level2", "Level3", "Level4"]):
    ax.bar(x - bar_width/2, gm_level[level], bar_width, bottom=bottom, label=f"GM {level}", color=gm_colors[i], alpha=0.7)
    bottom += gm_level[level]

bottom = np.zeros(len(depths))
for i, level in enumerate(["Level1", "Level2", "Level3", "Level4"]):
    ax.bar(x + bar_width/2, ass_level[level], bar_width, bottom=bottom, label=f"ASS {level}", color=ass_colors[i], alpha=0.7)
    bottom += ass_level[level]

ax2 = ax.twinx()
ax2.set_ylabel("False Negatives (FN)", color="black")
ax2.set_ylim(0, max(max(gm_FN["Concatenation_FN"]), max(ass_FN["Concatenation_FN"]), 10))

ax2.plot(x - bar_width/2, gm_FN["Concatenation_FN"], color=gm_FN_colors["Concatenation"], marker="o", linestyle="--", label="GM FN (Concatenation)")
ax2.plot(x - bar_width/2, gm_FN["Coalescent_FN"], color=gm_FN_colors["Coalescent"], marker="o", linestyle=":", label="GM FN (Coalescent)")
ax2.plot(x + bar_width/2, ass_FN["Concatenation_FN"], color=ass_FN_colors["Concatenation"], marker="s", linestyle="--", label="ASS FN (Concatenation)")
ax2.plot(x + bar_width/2, ass_FN["Coalescent_FN"], color=ass_FN_colors["Coalescent"], marker="s", linestyle=":", label="ASS FN (Coalescent)")

ax.set_xticks(x)
ax.set_xticklabels(depths, rotation=45)
ax.set_xlabel("Sequencing Depth")
ax.set_ylabel("Counts for Levels")
ax.set_title("Comparison of GeneMiner2 vs Assemble at Different Sequencing Depths with FN(ref_mutate=0.1)")

ax.set_xlim(-0.5, len(depths) - 0.5)

ax.spines["top"].set_visible(False)
ax2.spines["top"].set_visible(False)

handles, labels = ax.get_legend_handles_labels()
handles2, labels2 = ax2.get_legend_handles_labels()
by_label = dict(zip(labels + labels2, handles + handles2))
fig.legend(by_label.values(), by_label.keys(), loc="upper center", bbox_to_anchor=(0.5, -0.04), ncol=3, frameon=False)

output_path_final_fn = "qs20_0.1.png"
plt.tight_layout()
plt.savefig(output_path_final_fn, bbox_inches="tight")
plt.close()

output_path_final_fn
