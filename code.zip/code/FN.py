import os
import csv
from ete3 import Tree

def get_bipartitions(tree):
    bipartitions = set()
    for node in tree.traverse("postorder"):
        if not node.is_leaf():
            leaves = frozenset(node.get_leaf_names())
            bipartitions.add(leaves)
    return bipartitions

def calculate_fn_fp(true_tree_path, recovered_tree_path):
    try:
        true_tree = Tree(true_tree_path, format=1)
        recovered_tree = Tree(recovered_tree_path, format=1)

        true_bipartitions = get_bipartitions(true_tree)
        recovered_bipartitions = get_bipartitions(recovered_tree)

        FN = len(true_bipartitions - recovered_bipartitions)
        FP = len(recovered_bipartitions - true_bipartitions)

        return FN, FP
    except Exception as e:
        return f"Error: {e}", None

def process_trees(input_folder, gold_standard_path, output_csv):
    results = []

    for i in range(1, 11):
        subfolder_path = os.path.join(input_folder, str(i))
        if not os.path.isdir(subfolder_path):
            print(f"Subfolder {subfolder_path} does not exist.")
            continue

        concatenation_tree = os.path.join(subfolder_path, "Concatenation.tree")
        if os.path.exists(concatenation_tree):
            FN, FP = calculate_fn_fp(gold_standard_path, concatenation_tree)
            results.append([i, "Concatenation", FN, FP])

        coalescent_tree = os.path.join(subfolder_path, "Coalescent.tree")
        if os.path.exists(coalescent_tree):
            FN, FP = calculate_fn_fp(gold_standard_path, coalescent_tree)
            results.append([i, "Coalescent", FN, FP])

    with open(output_csv, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Folder", "Tree_Type", "FN", "FP"])
        writer.writerows(results)

    print(f"Results saved to {output_csv}")

input_folder = "ass-after"
gold_standard_path = "./3.tree"
output_csv = "fn_fp_results_ass.csv"

process_trees(input_folder, gold_standard_path, output_csv)
