#!/bin/bash
set -eu
cd ../output/$1

hybpiper stats -t_dna ../../scripts/Apiaceae_scg.fasta gene ../../../name_list.txt
hybpiper retrieve_sequences -t_dna ../../scripts/Apiaceae_scg.fasta --sample_names ../../../name_list.txt --fasta_dir sequences --skip_chimeric_genes dna
#hybpiper paralog_retriever --targetfile_dna Apiaceae_scg.fasta --hybpiper_dir . --fasta_dir_no_chimeras paralogs_high_confidence --paralogs_above_threshold_report_filename paralogs_above_threshold_report ../../../name_list.txt

find sequences -empty -delete
#以下得到的是没有para的
mkdir -p seq_align
for f in sequences/*.FNA
do
    gene=$(basename "$f" .FNA)
    gawk -i inplace '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$f"
    mafft --thread -1 --auto "$f" > "seq_align/${gene}.fasta"
done
find seq_align -empty -delete

mkdir -p seq_trim
parallel -j ${threads:-1} trimal -in {} -out seq_trim/{/} -automated1 ::: seq_align/*.fasta
find seq_trim -empty -delete

for f in seq_trim/*.fasta
do
    seq_count=$(grep -c ">" "$f")
    if [[ $seq_count -le 3 ]]
    then
        rm "$f"
    fi
done

cat seq_trim/*.fasta > combined_sequences.fasta
FastTree -nt combined_sequences.fasta > Concatenation.newick

mkdir -p seq_trees
parallel -j ${threads:-1} "FastTree -gtr -gamma -nt -nosupport {} > seq_trees/{/.}_tree.nwk" ::: seq_trim/*.fasta

cat seq_trees/*.nwk > all_gene_trees.nwk
astral -i all_gene_trees.nwk -o astral_species_tree.nwk
