set -eu

export threads=20

echo -n '' > ../time.txt
echo 'Assembly using genome data:' >> ../time.txt
/bin/time -a -v -o ../time.txt ./assemble.sh genome fq.gz

echo '' >> ../time.txt
echo 'Building tree using genome data:' >> ../time.txt
/bin/time -a -v -o ../time.txt ./build_tree.sh genome fq.gz

echo '' >> ../time.txt
echo 'Assembly using transcriptome data:' >> ../time.txt
/bin/time -a -v -o ../time.txt ./assemble.sh trans fastq.gz

echo '' >> ../time.txt
echo 'Building tree using transcriptome data:' >> ../time.txt
/bin/time -a -v -o ../time.txt ./build_tree.sh trans fastq.gz
