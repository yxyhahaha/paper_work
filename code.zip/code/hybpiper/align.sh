mkdir -p seq_align
for f in sequences/output/*.FNA
do
    gene=$(basename "$f" .FNA)
    gawk -i inplace '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$f"
    mafft --thread -1 --auto "$f" > "seq_align/${gene}.fasta"
done
find seq_align -empty -delete

mkdir -p seq_trim
parallel -j ${threads:-1} trimal -in {} -out seq_trim/{/} -automated1 ::: seq_align/*.fasta
find seq_trim -empty -delete

for f in seq_trim/*.fasta
do
    seq_count=$(grep -c ">" "$f")
    if [[ $seq_count -le 3 ]]
    then
        rm "$f"
    fi
done

mkdir -p seq_trees
parallel -j ${threads:-1} "FastTree -gtr -gamma -nt -nosupport {} > seq_trees/{/.}_tree.nwk" ::: seq_trim/*.fasta

cat seq_trees/*.nwk > all_gene_trees.nwk
astral -i all_gene_trees.nwk -o astral_species_tree.nwk
