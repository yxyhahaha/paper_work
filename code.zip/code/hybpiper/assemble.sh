#!/bin/bash
set -eu

rm -rf ../output/$1
mkdir -p ../output/$1
cd ../output/$1

readarray -t list < ../../../$1_list.txt
for name in "${list[@]}"
do
    prefix=${name%.}
    prefix=${prefix%_}
    hybpiper assemble --bwa --cpu ${threads:-1} -r ../../../$1/${name}1.$2 ../../../$1/${name}2.$2 -t_dna ../../scripts/Apiaceae_scg.fasta --prefix $prefix --chimeric_stitched_contig_check
done
