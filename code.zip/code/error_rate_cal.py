import os
import subprocess
import argparse
from Bio import SeqIO
import pandas as pd

parser = argparse.ArgumentParser(description="Run BLAST for corresponding FASTA files in two folders and summarize results.")
parser.add_argument("-f1", "--folder1", required=True, help="Path to the gold standard FASTA files folder (e.g., /path/to/folder1).")
parser.add_argument("-f2", "--folder2", required=True, help="Path to the comparison FASTA files folder (e.g., /path/to/folder2).")
parser.add_argument("-o", "--output", required=True, help="Path to the output BLAST results folder (e.g., /path/to/output).")
parser.add_argument("-csv", "--csv_output", required=True, help="Path to the final summary CSV file (e.g., /path/to/summary.csv).")

args = parser.parse_args()

folder1 = args.folder1
folder2 = args.folder2
blast_output_folder = args.output
csv_output = args.csv_output

os.makedirs(blast_output_folder, exist_ok=True)

files1 = {os.path.basename(f): os.path.join(folder1, f) for f in os.listdir(folder1) if f.endswith('.fasta')}
files2 = {os.path.basename(f): os.path.join(folder2, f) for f in os.listdir(folder2) if f.endswith('.fasta')}

summary_data = []

for filename, path1 in files1.items():
    if filename in files2:
        path2 = files2[filename]
        output_path = os.path.join(blast_output_folder, f'blast_{filename.replace(".fasta", ".txt")}')
        try:
            subprocess.run(["blastn", "-query", path1, "-subject", path2,
                            "-outfmt", "6 qseqid sseqid pident length qlen mismatch gaps", "-out", output_path], check=True)
        except subprocess.CalledProcessError as e:
            print(f"Error running BLAST for {filename}: {e}")
            summary_data.append([filename, None, None])
            continue
        try:
            results = pd.read_csv(output_path, sep='\t', header=None, 
                                  names=['qseqid', 'sseqid', 'pident', 'length', 'qlen', 'mismatch', 'gaps'])

            if not results.empty:
                filtered_results = results[results['qseqid'] == results['sseqid']]
                total_error_bases = filtered_results['mismatch'].sum() if not filtered_results.empty else 0
                total_indel_errors = filtered_results['gaps'].sum() if not filtered_results.empty else 0
                total_comparison_length = sum(len(record.seq) for record in SeqIO.parse(path2, "fasta"))
                error_rate = total_error_bases / total_comparison_length if total_comparison_length > 0 else 0
                indel_rate = total_indel_errors / total_comparison_length if total_comparison_length > 0 else 0
            else:
                total_error_bases = 0
                total_indel_errors = 0
                error_rate = 0
                indel_rate = 0
            summary_data.append([filename, error_rate, indel_rate])
        except FileNotFoundError:
            summary_data.append([filename, None, None])

output_df = pd.DataFrame(summary_data, columns=['File Name', 'Base-calling Error Rate', 'Indel Error Rate'])

total_length = sum(len(record.seq) for file in files2.values() for record in SeqIO.parse(file, "fasta"))
total_error_bases = sum(row[1] for row in summary_data if row[1] is not None)
total_indel_errors = sum(row[2] for row in summary_data if row[2] is not None)

total_error_rate = total_error_bases / total_length if total_length > 0 else 0
total_indel_rate = total_indel_errors / total_length if total_length > 0 else 0

total_row = pd.DataFrame([['Total', total_error_rate, total_indel_rate]], columns=output_df.columns)
output_df = pd.concat([output_df, total_row], ignore_index=True)

output_df.to_csv(csv_output, index=False, encoding='utf-8')

mean_error_rate = output_df['Base-calling Error Rate'].mean(skipna=True) if not output_df['Base-calling Error Rate'].isnull().all() else 0
mean_indel_rate = output_df['Indel Error Rate'].mean(skipna=True) if not output_df['Indel Error Rate'].isnull().all() else 0

mean_error_rate_str = "{:.2e}".format(mean_error_rate) if mean_error_rate is not None else "N/A"
mean_indel_rate_str = "{:.2e}".format(mean_indel_rate) if mean_indel_rate is not None else "N/A"

print(f"Error Rate calculation completed. Results saved to {csv_output}")
print(f"Average Base-calling Error Rate: {mean_error_rate_str}")
print(f"Average Indel Error Rate: {mean_indel_rate_str}")
