cd 1/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim1.tar.gz *.fasta
cd ../../../../../

cd 2/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim2.tar.gz *.fasta
cd ../../../../../

cd 3/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim3.tar.gz *.fasta
cd ../../../../../


cd 4/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim4.tar.gz *.fasta
cd ../../../../../

cd 5/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim5.tar.gz *.fasta
cd ../../../../../

cd 6/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim6.tar.gz *.fasta
cd ../../../../../

cd 7/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim7.tar.gz *.fasta
cd ../../../../../

cd 8/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim8.tar.gz *.fasta
cd ../../../../../

cd 9/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim9.tar.gz *.fasta
cd ../../../../../

cd 10/mega/combine
mkdir align
for f in *.fasta; do mafft --auto "$f" > "align/${f%.fasta}.fasta"; done
cd align
for file in ./*.fasta; do awk '/^>/ {print; next} {gsub(/[Nn]/, "-"); print}' "$file" > temp && mv temp "$file"; done
mkdir -p trim
for f in *.fasta; do trimal -in "$f" -out "trim/${f%.fasta}.fasta" -automated1; done
cd trim
tar -czvf trim10.tar.gz *.fasta
cd ../../../../../

