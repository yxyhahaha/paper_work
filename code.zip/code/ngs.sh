ngsngs -i A_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/A -qs 20 -s 101
ngsngs -i B_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/B -qs 20 -s 102
ngsngs -i C_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/C -qs 20 -s 103
ngsngs -i D_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/D -qs 20 -s 104
ngsngs -i E_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/E -qs 20 -s 105
ngsngs -i F_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/F -qs 20 -s 106
ngsngs -i G_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/G -qs 20 -s 107
ngsngs -i H_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/H -qs 20 -s 108
ngsngs -i I_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/I -qs 20 -s 109
ngsngs -i J_extended.fasta -c 1 -l 150 -seq PE -f fq -o 1/J -qs 20 -s 110
tar -czvf 1.tar.gz 1/*.fq

ngsngs -i A_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/A -qs 20 -s 111
ngsngs -i B_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/B -qs 20 -s 112
ngsngs -i C_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/C -qs 20 -s 113
ngsngs -i D_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/D -qs 20 -s 114
ngsngs -i E_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/E -qs 20 -s 115
ngsngs -i F_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/F -qs 20 -s 116
ngsngs -i G_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/G -qs 20 -s 117
ngsngs -i H_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/H -qs 20 -s 118
ngsngs -i I_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/I -qs 20 -s 119
ngsngs -i J_extended.fasta -c 2 -l 150 -seq PE -f fq -o 2/J -qs 20 -s 120
tar -czvf 2.tar.gz 2/*.fq

ngsngs -i A_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/A -qs 20 -s 121
ngsngs -i B_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/B -qs 20 -s 122
ngsngs -i C_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/C -qs 20 -s 123
ngsngs -i D_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/D -qs 20 -s 124
ngsngs -i E_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/E -qs 20 -s 125
ngsngs -i F_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/F -qs 20 -s 126
ngsngs -i G_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/G -qs 20 -s 127
ngsngs -i H_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/H -qs 20 -s 128
ngsngs -i I_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/I -qs 20 -s 129
ngsngs -i J_extended.fasta -c 3 -l 150 -seq PE -f fq -o 3/J -qs 20 -s 130
tar -czvf 3.tar.gz 3/*.fq

ngsngs -i A_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/A -qs 20 -s 131
ngsngs -i B_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/B -qs 20 -s 132
ngsngs -i C_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/C -qs 20 -s 133
ngsngs -i D_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/D -qs 20 -s 134
ngsngs -i E_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/E -qs 20 -s 135
ngsngs -i F_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/F -qs 20 -s 136
ngsngs -i G_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/G -qs 20 -s 137
ngsngs -i H_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/H -qs 20 -s 138
ngsngs -i I_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/I -qs 20 -s 139
ngsngs -i J_extended.fasta -c 4 -l 150 -seq PE -f fq -o 4/J -qs 20 -s 140
tar -czvf 4.tar.gz 4/*.fq

ngsngs -i A_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/A -qs 20 -s 141
ngsngs -i B_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/B -qs 20 -s 142
ngsngs -i C_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/C -qs 20 -s 143
ngsngs -i D_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/D -qs 20 -s 144
ngsngs -i E_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/E -qs 20 -s 145
ngsngs -i F_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/F -qs 20 -s 146
ngsngs -i G_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/G -qs 20 -s 147
ngsngs -i H_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/H -qs 20 -s 148
ngsngs -i I_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/I -qs 20 -s 149
ngsngs -i J_extended.fasta -c 5 -l 150 -seq PE -f fq -o 5/J -qs 20 -s 150
tar -czvf 5.tar.gz 5/*.fq

ngsngs -i A_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/A -qs 20 -s 151
ngsngs -i B_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/B -qs 20 -s 152
ngsngs -i C_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/C -qs 20 -s 153
ngsngs -i D_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/D -qs 20 -s 154
ngsngs -i E_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/E -qs 20 -s 155
ngsngs -i F_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/F -qs 20 -s 156
ngsngs -i G_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/G -qs 20 -s 157
ngsngs -i H_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/H -qs 20 -s 158
ngsngs -i I_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/I -qs 20 -s 159
ngsngs -i J_extended.fasta -c 6 -l 150 -seq PE -f fq -o 6/J -qs 20 -s 160
tar -czvf 6.tar.gz 6/*.fq

ngsngs -i A_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/A -qs 20 -s 161
ngsngs -i B_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/B -qs 20 -s 162
ngsngs -i C_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/C -qs 20 -s 163
ngsngs -i D_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/D -qs 20 -s 164
ngsngs -i E_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/E -qs 20 -s 165
ngsngs -i F_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/F -qs 20 -s 166
ngsngs -i G_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/G -qs 20 -s 167
ngsngs -i H_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/H -qs 20 -s 168
ngsngs -i I_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/I -qs 20 -s 169
ngsngs -i J_extended.fasta -c 7 -l 150 -seq PE -f fq -o 7/J -qs 20 -s 170
tar -czvf 7.tar.gz 7/*.fq

ngsngs -i A_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/A -qs 20 -s 171
ngsngs -i B_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/B -qs 20 -s 172
ngsngs -i C_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/C -qs 20 -s 173
ngsngs -i D_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/D -qs 20 -s 174
ngsngs -i E_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/E -qs 20 -s 175
ngsngs -i F_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/F -qs 20 -s 176
ngsngs -i G_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/G -qs 20 -s 177
ngsngs -i H_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/H -qs 20 -s 178
ngsngs -i I_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/I -qs 20 -s 179
ngsngs -i J_extended.fasta -c 8 -l 150 -seq PE -f fq -o 8/J -qs 20 -s 180
tar -czvf 8.tar.gz 8/*.fq

ngsngs -i A_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/A -qs 20 -s 181
ngsngs -i B_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/B -qs 20 -s 182
ngsngs -i C_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/C -qs 20 -s 183
ngsngs -i D_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/D -qs 20 -s 184
ngsngs -i E_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/E -qs 20 -s 185
ngsngs -i F_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/F -qs 20 -s 186
ngsngs -i G_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/G -qs 20 -s 187
ngsngs -i H_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/H -qs 20 -s 188
ngsngs -i I_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/I -qs 20 -s 189
ngsngs -i J_extended.fasta -c 9 -l 150 -seq PE -f fq -o 9/J -qs 20 -s 190
tar -czvf 9.tar.gz 9/*.fq


ngsngs -i A_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/A -qs 20 -s 191
ngsngs -i B_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/B -qs 20 -s 192
ngsngs -i C_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/C -qs 20 -s 193
ngsngs -i D_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/D -qs 20 -s 194
ngsngs -i E_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/E -qs 20 -s 195
ngsngs -i F_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/F -qs 20 -s 196
ngsngs -i G_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/G -qs 20 -s 197
ngsngs -i H_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/H -qs 20 -s 198
ngsngs -i I_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/I -qs 20 -s 199
ngsngs -i J_extended.fasta -c 10 -l 150 -seq PE -f fq -o 10/J -qs 20 -s 200
tar -czvf 10.tar.gz 10/*.fq
