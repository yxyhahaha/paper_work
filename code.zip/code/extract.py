import os
import argparse
from Bio import SeqIO

def extract_sequences_by_folder(blast_result_file, genome_fasta_file, output_folder, folder_name):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    genome_dict = SeqIO.to_dict(SeqIO.parse(genome_fasta_file, "fasta"))

    with open(blast_result_file, 'r') as blast_file:
        for line in blast_file:
            fields = line.strip().split()
            qseqid = fields[0]
            sseqid = fields[1]
            qstart = int(fields[2]) - 1
            qend = int(fields[3])

            if folder_name in sseqid:
                numeric_part = ''.join(filter(str.isdigit, sseqid))

                if qseqid in genome_dict:
                    sequence = genome_dict[qseqid].seq[qstart:qend]

                    output_file_path = os.path.join(output_folder, f"{numeric_part}.fasta")

                    with open(output_file_path, 'w') as output_file:
                        output_file.write(f">{folder_name}\n")
                        output_file.write(str(sequence) + "\n")
                else:
                    print(f"Warning: {qseqid} not found in the genome.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extract sequences by folder name from BLAST results.")
    parser.add_argument("-b", "--blast", required=True, help="Path to the BLAST results file.")
    parser.add_argument("-i", "--input", required=True, help="Path to the genome FASTA file.")
    parser.add_argument("-o", "--output", required=True, help="Path to the output folder.")

    args = parser.parse_args()

    folder_name = os.path.basename(os.path.dirname(args.blast))

    extract_sequences_by_folder(args.blast, args.input, args.output, folder_name)
