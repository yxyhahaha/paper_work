import os
import re

def convert_support_to_float(file_path):
    """
    Convert integer support values to float format in a Newick tree.
    """
    try:
        with open(file_path, 'r') as file:
            content = file.read().strip()
        # Use regex to match support values (e.g., )1, )95 and convert them to float (e.g., )1.0, )95.0)
        converted_content = re.sub(r'\)(\d+)(?=:)', r')\1.0', content)
        return converted_content
    except Exception as e:
        print(f"Error processing file {file_path}: {e}")
        return None

def process_trees_in_subfolders(input_folder, output_folder):
    """
    Process tree files in subfolders 1 to 5, converting support values to float format.
    """
    for i in range(1, 11):  # Subfolders named 1 to 5
        subfolder_path = os.path.join(input_folder, str(i))
        if os.path.isdir(subfolder_path):
            output_subfolder = os.path.join(output_folder, str(i))
            os.makedirs(output_subfolder, exist_ok=True)

            # Look for tree files in the subfolder
            concatenation_tree = os.path.join(subfolder_path, "Concatenation.tree")
            coalescent_tree = os.path.join(subfolder_path, "Coalescent.tree")

            if os.path.exists(concatenation_tree):
                new_content = convert_support_to_float(concatenation_tree)
                if new_content:
                    output_file = os.path.join(output_subfolder, "Concatenation.tree")
                    with open(output_file, 'w') as f:
                        f.write(new_content)
                        print(f"Processed {concatenation_tree} -> {output_file}")

            if os.path.exists(coalescent_tree):
                new_content = convert_support_to_float(coalescent_tree)
                if new_content:
                    output_file = os.path.join(output_subfolder, "Coalescent.tree")
                    with open(output_file, 'w') as f:
                        f.write(new_content)
                        print(f"Processed {coalescent_tree} -> {output_file}")

# Define the input and output folders
input_folder = "gene-tree"  # Replace with your input folder path
output_folder = "gene-after"  # Replace with your desired output folder path

# Process the trees
process_trees_in_subfolders(input_folder, output_folder)
