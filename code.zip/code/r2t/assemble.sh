#!/bin/bash
set -eu

rm -rf ../output/$1
mkdir -p ../output/$1
read2tree --standalone_path marker_genes/ --output_path ../output/$1 --reference --dna_reference dna_ref.fa

readarray -t list < ../../$1_list.txt
for name in "${list[@]}"
do
    read2tree --threads ${threads:-1} --standalone_path marker_genes/ --output_path ../output/$1 --reads ../../$1/${name}1.$2 ../../$1/${name}2.$2
done
