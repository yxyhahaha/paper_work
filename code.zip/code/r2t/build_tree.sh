#!/bin/bash
set -eu
read2tree --standalone_path marker_genes/ --output_path ../output/$1 --merge_all_mappings
iqtree -T AUTO -ntmax ${threads:-1} -s ../output/$1/concat_merge_aa.phy -bb 1000
